function pref() {
    window.location.href="/pref.html"
}